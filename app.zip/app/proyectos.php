<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class proyectos extends Model
{
    protected $table = 't_proyecto';
    protected $primaryKey = 'Proyecto_ID';
}
