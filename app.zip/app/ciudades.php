<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ciudades extends Model
{
    protected $table = 'municipios';


}
