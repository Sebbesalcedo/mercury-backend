<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ciudad_departamento extends Model
{
    protected $table = 'departamentos';
}
